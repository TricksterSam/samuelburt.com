To use this modular synth in windows, download Pure Data, a visual programming environment. In addition to running the file _modular.synth.pd, you can make your own audio and video applications!

http://puredata.info/downloads

