To play the score of Artikulation:

1. Convert your copy of the file to a wave file and rename it "artikulation.wav".

2. Place "articulation" in the "ligeti" folder with the other files.

3. Double-click _Ligeti.pd to launch the file.

4. Select whether you would like to play the file windowed or fullscreen on your primary display or secondary display.

5. Activate visuals.

6. Begin playback.