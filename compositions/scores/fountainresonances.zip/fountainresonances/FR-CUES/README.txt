-FR-cues.pd

This file can be run from another computer in Pure Data as a virtual conductor.  Someone should follow the saxophone with a score and trigger the cue changes which can be displayed on a second monitor to the string players.

